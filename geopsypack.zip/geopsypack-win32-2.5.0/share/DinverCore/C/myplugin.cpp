/*
  Do not alter this file.

  This is required by dinver to recognize this library as a plugin.

  You can rename myplugin.h and myplugin.cpp, if you also change the include
  here below.
*/

#include "myplugin.h"

Q_EXPORT_PLUGIN2( dinverc, CPlugin );

